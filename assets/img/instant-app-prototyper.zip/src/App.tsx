import React, { useState, useEffect, useMemo } from 'react';
import {
  Calculator,
  History,
  Apple,
  Trash2,
  Plus,
  Search,
  Save,
  RotateCcw,
  Percent,
  Clock,
  Sparkles,
  Check,
  Edit2,
  ChevronRight,
  Utensils,
  BookOpen,
  Info,
  Scale,
  Settings,
  Menu,
  X,
  FileDown,
  FileUp,
  AlertCircle
} from 'lucide-react';

// Interfaces
interface Ingredient {
  id: string;
  name: string;
  purchasePrice: number; // e.g. 1500
  purchaseQuantity: number; // e.g. 1000
  purchaseUnit: 'g' | 'ml' | 'u' | 'kg' | 'L';
  category: string; // e.g. "Lácteos", "Secos"
  pricePerUnit: number; // calculated cost per base unit (g, ml, u)
}

interface RecipeItem {
  ingredientId: string;
  quantity: number; // in base units (g, ml, u)
}

interface Calculation {
  id: string;
  name: string;
  date: string;
  items: RecipeItem[];
  fixedCosts?: { id: string; name: string; amount: number }[];
  fixedCostsTotal?: number;
  laborMode: 'fixed' | 'hourly' | 'multiplier' | 'percentage';
  laborFixedAmount: number;
  laborHourlyHours: number;
  laborHourlyRate: number;
  laborMultiplier: number;
  laborPercentage: number;
  margin: number;
  portions: number;
  rawMaterialsCost: number;
  laborCost: number;
  productionCost: number;
  suggestedPrice: number;
  netProfit: number;
}

// Initial Standard Ingredients Dictionary
const INITIAL_INGREDIENTS: Ingredient[] = [
  { id: 'ing-1', name: 'Arroz', purchasePrice: 1500, purchaseQuantity: 1000, purchaseUnit: 'g', category: 'Granos', pricePerUnit: 1.5 },
  { id: 'ing-2', name: 'Azúcar Flor', purchasePrice: 1200, purchaseQuantity: 500, purchaseUnit: 'g', category: 'Azúcares', pricePerUnit: 2.4 },
  { id: 'ing-3', name: 'Harina de Trigo', purchasePrice: 1800, purchaseQuantity: 1000, purchaseUnit: 'g', category: 'Secos', pricePerUnit: 1.8 },
  { id: 'ing-4', name: 'Mantequilla', purchasePrice: 2500, purchaseQuantity: 250, purchaseUnit: 'g', category: 'Lácteos', pricePerUnit: 10.0 },
  { id: 'ing-5', name: 'Huevos', purchasePrice: 3600, purchaseQuantity: 12, purchaseUnit: 'u', category: 'Otros', pricePerUnit: 300.0 },
  { id: 'ing-6', name: 'Leche Entera', purchasePrice: 1100, purchaseQuantity: 1000, purchaseUnit: 'ml', category: 'Lácteos', pricePerUnit: 1.1 },
  { id: 'ing-7', name: 'Chocolate Bitter', purchasePrice: 5000, purchaseQuantity: 500, purchaseUnit: 'g', category: 'Chocolates', pricePerUnit: 10.0 },
  { id: 'ing-8', name: 'Polvo de Hornear', purchasePrice: 900, purchaseQuantity: 100, purchaseUnit: 'g', category: 'Secos', pricePerUnit: 9.0 }
];

// Initial Saved Calculations (History)
const INITIAL_CALCULATIONS: Calculation[] = [
  {
    id: 'calc-1',
    name: 'Torta Selva Negra Premium',
    date: '2026-08-08',
    items: [
      { ingredientId: 'ing-3', quantity: 250 }, // Harina: 250g * 1.8 = 450
      { ingredientId: 'ing-2', quantity: 200 }, // Azúcar flor: 200g * 2.4 = 480
      { ingredientId: 'ing-4', quantity: 150 }, // Mantequilla: 150g * 10 = 1500
      { ingredientId: 'ing-5', quantity: 4 },   // Huevos: 4u * 300 = 1200
      { ingredientId: 'ing-6', quantity: 100 },  // Leche: 100ml * 1.1 = 110
      { ingredientId: 'ing-7', quantity: 150 }   // Chocolate: 150g * 10 = 1500
    ], // Total Mat Prima = 450+480+1500+1200+110+1500 = 5240
    laborMode: 'multiplier',
    laborFixedAmount: 2000,
    laborHourlyHours: 2,
    laborHourlyRate: 2500,
    laborMultiplier: 2, // laborCost = 5240 * (2 - 1) = 5240
    laborPercentage: 50,
    margin: 50, // 50% profit margin
    portions: 15,
    rawMaterialsCost: 5240,
    laborCost: 5240,
    productionCost: 10480,
    suggestedPrice: 15720,
    netProfit: 5240
  },
  {
    id: 'calc-2',
    name: 'Queque de Vainilla Casero',
    date: '2026-08-06',
    items: [
      { ingredientId: 'ing-3', quantity: 300 }, // Harina: 300g * 1.8 = 540
      { ingredientId: 'ing-1', quantity: 200 }, // Arroz (como relleno o sustituto): 200g * 1.5 = 300
      { ingredientId: 'ing-4', quantity: 100 }, // Mantequilla: 100g * 10 = 1000
      { ingredientId: 'ing-5', quantity: 3 },   // Huevos: 3u * 300 = 900
      { ingredientId: 'ing-6', quantity: 150 },  // Leche: 150ml * 1.1 = 165
      { ingredientId: 'ing-8', quantity: 10 }    // Polvo hornear: 10g * 9 = 90
    ], // Total Mat Prima = 540+300+1000+900+165+90 = 2995
    laborMode: 'hourly',
    laborFixedAmount: 0,
    laborHourlyHours: 1.5,
    laborHourlyRate: 3000, // laborCost = 1.5 * 3000 = 4500
    laborMultiplier: 2,
    laborPercentage: 30,
    margin: 75, // 75% profit margin
    portions: 12,
    rawMaterialsCost: 2995,
    laborCost: 4500,
    productionCost: 7495,
    suggestedPrice: 13116,
    netProfit: 5621
  }
];

export default function App() {
  // Navigation tab
  const [activeTab, setActiveTab] = useState<'calculator' | 'history' | 'ingredients'>('calculator');

  // Core App State (With localStorage caching)
  const [ingredients, setIngredients] = useState<Ingredient[]>(() => {
    const cached = localStorage.getItem('chefcost_ingredients');
    return cached ? JSON.parse(cached) : INITIAL_INGREDIENTS;
  });

  const [calculations, setCalculations] = useState<Calculation[]>(() => {
    const cached = localStorage.getItem('chefcost_calculations');
    return cached ? JSON.parse(cached) : INITIAL_CALCULATIONS;
  });

  // Save to localStorage on change
  useEffect(() => {
    localStorage.setItem('chefcost_ingredients', JSON.stringify(ingredients));
  }, [ingredients]);

  useEffect(() => {
    localStorage.setItem('chefcost_calculations', JSON.stringify(calculations));
  }, [calculations]);

  // General App Settings & Default Multipliers
  const [defaultHourlyRate, setDefaultHourlyRate] = useState<number>(3000);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showMenu, setShowMenu] = useState<boolean>(false);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Trigger temporary toast notification
  const triggerNotification = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // --- CURRENT CALCULATOR STATE ---
  const [calcName, setCalcName] = useState<string>('Nuevo Cálculo de Torta');
  const [calcItems, setCalcItems] = useState<RecipeItem[]>([
    { ingredientId: 'ing-1', quantity: 50 },
    { ingredientId: 'ing-2', quantity: 300 }
  ]);
  const [calcFixedCosts, setCalcFixedCosts] = useState<{ id: string; name: string; amount: number }[]>([
    { id: 'fc-1', name: 'Gas / Energía', amount: 500 },
    { id: 'fc-2', name: 'Envases / Packaging', amount: 800 }
  ]);
  const [laborMode, setLaborMode] = useState<'fixed' | 'hourly' | 'multiplier' | 'percentage'>('multiplier');
  const [laborFixedAmount, setLaborFixedAmount] = useState<number>(3000);
  const [laborHourlyHours, setLaborHourlyHours] = useState<number>(2);
  const [laborHourlyRate, setLaborHourlyRate] = useState<number>(3000);
  const [laborMultiplier, setLaborMultiplier] = useState<number>(2);
  const [laborPercentage, setLaborPercentage] = useState<number>(30);
  const [margin, setMargin] = useState<number>(50); // Margin as % (e.g. 50% means salePrice = productionCost * 1.5)
  const [portions, setPortions] = useState<number>(12);

  // Editing state tracker (If loaded an existing calculation, track its ID)
  const [activeCalculationId, setActiveCalculationId] = useState<string | null>(null);

  // Search & Filter for Ingredients Drawer
  const [searchIngredientQuery, setSearchIngredientQuery] = useState<string>('');
  const [showAddIngredientDrawer, setShowAddIngredientDrawer] = useState<boolean>(false);

  // Ingredient creation/edit state for managing the dictionary
  const [isEditingDictIngredient, setIsEditingDictIngredient] = useState<boolean>(false);
  const [dictEditId, setDictEditId] = useState<string | null>(null);
  const [dictName, setDictName] = useState<string>('');
  const [dictPrice, setDictPrice] = useState<number>(1500);
  const [dictQty, setDictQty] = useState<number>(1000);
  const [dictUnit, setDictUnit] = useState<'g' | 'ml' | 'u' | 'kg' | 'L'>('g');
  const [dictCategory, setDictCategory] = useState<string>('Secos');
  const [showDictModal, setShowDictModal] = useState<boolean>(false);

  // --- DYNAMIC COMPUTATIONS ---
  // Calculates live recipe summary parameters based on states
  const computations = useMemo(() => {
    // 1. Raw materials cost
    let rawMaterialsCost = 0;
    calcItems.forEach(item => {
      const ing = ingredients.find(i => i.id === item.ingredientId);
      if (ing) {
        rawMaterialsCost += item.quantity * ing.pricePerUnit;
      }
    });

    // 2. Labor cost
    let laborCost = 0;
    if (laborMode === 'fixed') {
      laborCost = laborFixedAmount;
    } else if (laborMode === 'hourly') {
      laborCost = laborHourlyHours * laborHourlyRate;
    } else if (laborMode === 'multiplier') {
      // 2x duplica costo ingredientes, lo cual significa que la mano de obra es igual al costo de ingredientes
      laborCost = rawMaterialsCost * Math.max(0, laborMultiplier - 1);
    } else if (laborMode === 'percentage') {
      laborCost = rawMaterialsCost * (laborPercentage / 100);
    }

    // 2.5. Fixed costs (overhead)
    const fixedCostsTotal = calcFixedCosts.reduce((sum, item) => sum + item.amount, 0);

    // 3. Production cost
    const productionCost = rawMaterialsCost + laborCost + fixedCostsTotal;

    // 4. Suggested sale price (Production cost * (1 + margin / 100))
    const suggestedPrice = productionCost * (1 + margin / 100);

    // 5. Net profit (Suggested price - Production cost)
    const netProfit = suggestedPrice - productionCost;

    // 6. Price per portion
    const pricePerPortion = portions > 0 ? suggestedPrice / portions : 0;

    return {
      rawMaterialsCost,
      laborCost,
      fixedCostsTotal,
      productionCost,
      suggestedPrice,
      netProfit,
      pricePerPortion
    };
  }, [
    calcItems,
    ingredients,
    calcFixedCosts,
    laborMode,
    laborFixedAmount,
    laborHourlyHours,
    laborHourlyRate,
    laborMultiplier,
    laborPercentage,
    margin,
    portions
  ]);

  // Chilean / Spanish currency formatter
  const formatCurrency = (val: number) => {
    const isRound = Number.isInteger(val);
    return '$' + new Intl.NumberFormat('es-CL', {
      minimumFractionDigits: isRound ? 0 : 1,
      maximumFractionDigits: 1
    }).format(val);
  };

  // Convert unit label safely for display
  const getUnitName = (unit: string) => {
    switch (unit) {
      case 'g': return 'g';
      case 'ml': return 'ml';
      case 'u': return 'u';
      case 'kg': return 'kg';
      case 'L': return 'L';
      default: return unit;
    }
  };

  // --- ACTIONS & HANDLERS ---

  // Reset current calculator form
  const handleResetCalculator = () => {
    setCalcName('Nuevo Cálculo de Torta');
    setCalcItems([]);
    setCalcFixedCosts([
      { id: 'fc-1', name: 'Gas / Energía', amount: 500 },
      { id: 'fc-2', name: 'Envases / Packaging', amount: 800 }
    ]);
    setLaborMode('multiplier');
    setLaborMultiplier(2);
    setMargin(50);
    setPortions(12);
    setActiveCalculationId(null);
    triggerNotification('Calculadora reiniciada. ¡Comienza una nueva receta!', 'info');
  };

  // Add ingredient from dictionary to active calculation recipe items
  const handleAddItemToRecipe = (ingredientId: string) => {
    // Check if already in recipe
    const exists = calcItems.some(item => item.ingredientId === ingredientId);
    if (exists) {
      triggerNotification('Este ingrediente ya está en la receta.', 'error');
      return;
    }

    const ing = ingredients.find(i => i.id === ingredientId);
    if (!ing) return;

    // Add with default quantity depending on unit (e.g. 100g, 100ml, 1 unit)
    const defaultQty = ing.purchaseUnit === 'u' ? 1 : 100;
    setCalcItems([...calcItems, { ingredientId, quantity: defaultQty }]);
    setShowAddIngredientDrawer(false);
    triggerNotification(`Se añadió ${ing.name} a la receta.`);
  };

  // Remove ingredient from recipe
  const handleRemoveItemFromRecipe = (ingredientId: string) => {
    setCalcItems(calcItems.filter(item => item.ingredientId !== ingredientId));
  };

  // Update quantity of specific recipe item
  const handleUpdateItemQuantity = (ingredientId: string, value: number) => {
    const updated = calcItems.map(item => {
      if (item.ingredientId === ingredientId) {
        return { ...item, quantity: Math.max(0, value) };
      }
      return item;
    });
    setCalcItems(updated);
  };

  // --- FIXED COSTS HANDLERS ---
  const handleAddFixedCostItem = (name = 'Nuevo Gasto', amount = 1000) => {
    setCalcFixedCosts([...calcFixedCosts, { id: `fc-${Date.now()}`, name, amount }]);
  };

  const handleUpdateFixedCostItem = (id: string, field: 'name' | 'amount', value: any) => {
    setCalcFixedCosts(calcFixedCosts.map(item => {
      if (item.id === id) {
        return { ...item, [field]: value };
      }
      return item;
    }));
  };

  const handleRemoveFixedCostItem = (id: string) => {
    setCalcFixedCosts(calcFixedCosts.filter(item => item.id !== id));
  };

  // Save or update active calculation in History
  const handleSaveCalculation = () => {
    if (calcItems.length === 0) {
      triggerNotification('Añade al menos un ingrediente para guardar el cálculo.', 'error');
      return;
    }

    const today = new Date().toISOString().split('T')[0];

    const newCalculation: Calculation = {
      id: activeCalculationId || `calc-${Date.now()}`,
      name: calcName.trim() || 'Cálculo sin nombre',
      date: today,
      items: [...calcItems],
      fixedCosts: [...calcFixedCosts],
      fixedCostsTotal: computations.fixedCostsTotal,
      laborMode,
      laborFixedAmount,
      laborHourlyHours,
      laborHourlyRate,
      laborMultiplier,
      laborPercentage,
      margin,
      portions,
      rawMaterialsCost: computations.rawMaterialsCost,
      laborCost: computations.laborCost,
      productionCost: computations.productionCost,
      suggestedPrice: computations.suggestedPrice,
      netProfit: computations.netProfit
    };

    if (activeCalculationId) {
      // Update existing
      setCalculations(calculations.map(c => c.id === activeCalculationId ? newCalculation : c));
      triggerNotification('¡Cálculo actualizado con éxito!');
    } else {
      // Create new
      setCalculations([newCalculation, ...calculations]);
      setActiveCalculationId(newCalculation.id);
      triggerNotification('¡Cálculo guardado en el historial!');
    }

    // Go to history to let user see it
    setActiveTab('history');
  };

  // Load a calculation from history back into the editor
  const handleLoadCalculation = (calc: Calculation) => {
    setCalcName(calc.name);
    setCalcItems(calc.items);
    setCalcFixedCosts(calc.fixedCosts || []);
    setLaborMode(calc.laborMode);
    setLaborFixedAmount(calc.laborFixedAmount || 3000);
    setLaborHourlyHours(calc.laborHourlyHours || 2);
    setLaborHourlyRate(calc.laborHourlyRate || defaultHourlyRate);
    setLaborMultiplier(calc.laborMultiplier || 2);
    setLaborPercentage(calc.laborPercentage || 30);
    setMargin(calc.margin);
    setPortions(calc.portions);
    setActiveCalculationId(calc.id);

    setActiveTab('calculator');
    triggerNotification(`Cargado: ${calc.name}`, 'info');
  };

  // Delete a calculation from history
  const handleDeleteCalculation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Avoid loading it
    if (confirm('¿Estás seguro de que quieres eliminar este cálculo del historial?')) {
      setCalculations(calculations.filter(c => c.id !== id));
      if (activeCalculationId === id) {
        setActiveCalculationId(null);
      }
      triggerNotification('Cálculo eliminado.', 'info');
    }
  };

  // --- DICTIONARY INGREDIENT ACTIONS ---

  // Handle open modal for new ingredient
  const handleOpenAddDictIngredient = () => {
    setIsEditingDictIngredient(false);
    setDictEditId(null);
    setDictName('');
    setDictPrice(1500);
    setDictQty(1000);
    setDictUnit('g');
    setDictCategory('Otros');
    setShowDictModal(true);
  };

  // Handle open modal for edit ingredient
  const handleOpenEditDictIngredient = (ing: Ingredient, e: React.MouseEvent) => {
    e.stopPropagation();
    setIsEditingDictIngredient(true);
    setDictEditId(ing.id);
    setDictName(ing.name);
    setDictPrice(ing.purchasePrice);
    setDictQty(ing.purchaseQuantity);
    setDictUnit(ing.purchaseUnit);
    setDictCategory(ing.category);
    setShowDictModal(true);
  };

  // Save dictionary ingredient (Create or Edit)
  const handleSaveDictIngredient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dictName.trim()) {
      triggerNotification('Por favor escribe un nombre de ingrediente.', 'error');
      return;
    }

    // Calculate price per base unit (converting kg/L to g/ml internally to keep unit math simple and bug-free)
    let finalBaseQty = dictQty;
    let finalBaseUnit: 'g' | 'ml' | 'u' = 'g';

    if (dictUnit === 'kg') {
      finalBaseQty = dictQty * 1000;
      finalBaseUnit = 'g';
    } else if (dictUnit === 'L') {
      finalBaseQty = dictQty * 1000;
      finalBaseUnit = 'ml';
    } else {
      finalBaseUnit = dictUnit as 'g' | 'ml' | 'u';
    }

    const pricePerUnit = finalBaseQty > 0 ? dictPrice / finalBaseQty : 0;

    if (isEditingDictIngredient && dictEditId) {
      // Edit mode
      setIngredients(ingredients.map(i => {
        if (i.id === dictEditId) {
          return {
            ...i,
            name: dictName.trim(),
            purchasePrice: dictPrice,
            purchaseQuantity: dictQty,
            purchaseUnit: dictUnit,
            category: dictCategory,
            pricePerUnit
          };
        }
        return i;
      }));
      triggerNotification('Ingrediente actualizado en la base de datos.');
    } else {
      // Create mode
      const newIng: Ingredient = {
        id: `ing-${Date.now()}`,
        name: dictName.trim(),
        purchasePrice: dictPrice,
        purchaseQuantity: dictQty,
        purchaseUnit: dictUnit,
        category: dictCategory,
        pricePerUnit
      };
      setIngredients([...ingredients, newIng]);
      triggerNotification('Nuevo ingrediente guardado con éxito.');
    }

    setShowDictModal(false);
  };

  // Delete ingredient from dictionary
  const handleDeleteDictIngredient = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();

    // Check if ingredient is used in any calculations or active calculation
    const isUsedInActive = calcItems.some(item => item.ingredientId === id);
    const isUsedInSaved = calculations.some(c => c.items.some(item => item.ingredientId === id));

    if (isUsedInActive || isUsedInSaved) {
      if (!confirm('Este ingrediente está siendo usado en una o más recetas. Si lo eliminas, podría afectar los cálculos guardados. ¿Deseas eliminarlo de todos modos?')) {
        return;
      }
    }

    setIngredients(ingredients.filter(i => i.id !== id));
    // Also strip it from active calculator items so it doesn't crash
    setCalcItems(calcItems.filter(item => item.ingredientId !== id));
    triggerNotification('Ingrediente eliminado de la base de datos.', 'info');
  };

  // Import / Export JSON backup of data (Crucial professional tool for chefs!)
  const handleExportData = () => {
    const data = {
      ingredients,
      calculations,
      defaultHourlyRate
    };
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(data, null, 2))}`;
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', jsonString);
    downloadAnchor.setAttribute('download', `chefcost_pro_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    triggerNotification('Copia de seguridad descargada.');
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    const file = e.target.files?.[0];
    if (!file) return;

    fileReader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.ingredients && Array.isArray(parsed.ingredients)) {
          setIngredients(parsed.ingredients);
        }
        if (parsed.calculations && Array.isArray(parsed.calculations)) {
          setCalculations(parsed.calculations);
        }
        if (parsed.defaultHourlyRate) {
          setDefaultHourlyRate(parsed.defaultHourlyRate);
        }
        triggerNotification('¡Copia de seguridad importada con éxito!', 'success');
      } catch (err) {
        triggerNotification('Archivo no válido. Asegúrate de usar un backup de ChefCost Pro.', 'error');
      }
    };
    fileReader.readAsText(file);
  };

  // Filter dictionary ingredients by search query
  const filteredIngredients = ingredients.filter(ing =>
    ing.name.toLowerCase().includes(searchIngredientQuery.toLowerCase()) ||
    ing.category.toLowerCase().includes(searchIngredientQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col min-h-screen bg-app-dark text-slate-800 pb-28 md:pb-8 font-sans selection:bg-app-peach selection:text-on-app-peach">
      {/* HEADER / TOP BAR */}
      <header id="top-app-bar" className="bg-white text-gray-900 border-b-4 border-gray-900 sticky top-0 z-40 transition-colors duration-200">
        <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <button
              id="menu-toggle-btn"
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 border-2 border-transparent active:border-gray-900 hover:bg-gray-100 rounded transition-all duration-150"
              aria-label="Abrir menú"
            >
              <Menu className="w-6 h-6 stroke-[2.5]" />
            </button>
            <div className="flex items-center gap-2">
              <Utensils className="w-6 h-6 text-app-purple fill-current" />
              <h1 className="font-sans text-2xl font-black uppercase tracking-tighter text-gray-900 flex items-center gap-1.5">
                ChefCost <span className="bg-app-peach px-2 py-0.5 rounded text-gray-900 border-2 border-gray-900 text-xs font-black rotate-2 shadow-brutal-sm">PRO</span>
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="settings-toggle-btn"
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 border-2 border-transparent hover:border-gray-900 hover:bg-gray-100 active:translate-x-0.5 active:translate-y-0.5 rounded transition-all duration-150 text-gray-800"
              title="Configuración de la Aplicación"
            >
              <Settings className="w-5 h-5 stroke-[2.5]" />
            </button>
          </div>
        </div>
      </header>

      {/* NOTIFICATION TOAST */}
      {notification && (
        <div
          id="toast-notification"
          className={`fixed top-20 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-5 py-3 rounded border-2 border-gray-900 shadow-brutal text-sm font-bold animate-bounce transition-all ${
            notification.type === 'success'
              ? 'bg-emerald-400 text-gray-900'
              : notification.type === 'error'
              ? 'bg-rose-500 text-white'
              : 'bg-app-peach text-gray-900'
          }`}
        >
          {notification.type === 'error' ? <AlertCircle className="w-5 h-5" /> : <Check className="w-5 h-5" />}
          <span>{notification.message}</span>
        </div>
      )}

      {/* SIDEBAR/MENU OVERLAY */}
      {showMenu && (
        <div className="fixed inset-0 bg-black/60 z-50 flex" onClick={() => setShowMenu(false)}>
          <div
            className="w-72 bg-white text-gray-900 h-full border-r-4 border-gray-900 flex flex-col p-6 animate-slide-in shadow-brutal-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center pb-6 border-b-2 border-gray-200 mb-6">
              <h2 className="text-lg font-black uppercase tracking-tight text-gray-900">Menú ChefCost</h2>
              <button onClick={() => setShowMenu(false)} className="p-1 hover:bg-gray-100 border-2 border-transparent active:border-gray-900 rounded">
                <X className="w-5 h-5 stroke-[2.5]" />
              </button>
            </div>

            <div className="flex flex-col gap-3 flex-grow">
              <button
                id="menu-calc-btn"
                onClick={() => { setActiveTab('calculator'); setShowMenu(false); }}
                className={`flex items-center gap-3 px-4 py-3 border-2 border-gray-900 rounded font-bold transition-all text-left ${
                  activeTab === 'calculator'
                    ? 'bg-app-peach text-gray-900 shadow-brutal-sm'
                    : 'bg-white hover:bg-gray-50'
                }`}
              >
                <Calculator className="w-5 h-5" />
                <span>Calculadora de Costos</span>
              </button>

              <button
                id="menu-history-btn"
                onClick={() => { setActiveTab('history'); setShowMenu(false); }}
                className={`flex items-center gap-3 px-4 py-3 border-2 border-gray-900 rounded font-bold transition-all text-left ${
                  activeTab === 'history'
                    ? 'bg-app-peach text-gray-900 shadow-brutal-sm'
                    : 'bg-white hover:bg-gray-50'
                }`}
              >
                <History className="w-5 h-5" />
                <span>Historial de Cálculos</span>
              </button>

              <button
                id="menu-ing-btn"
                onClick={() => { setActiveTab('ingredients'); setShowMenu(false); }}
                className={`flex items-center gap-3 px-4 py-3 border-2 border-gray-900 rounded font-bold transition-all text-left ${
                  activeTab === 'ingredients'
                    ? 'bg-app-peach text-gray-900 shadow-brutal-sm'
                    : 'bg-white hover:bg-gray-50'
                }`}
              >
                <Apple className="w-5 h-5" />
                <span>Base de Ingredientes</span>
              </button>
            </div>

            <div className="pt-6 border-t-2 border-gray-200 space-y-4">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-widest text-center">Copia de Seguridad</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  id="export-data-btn"
                  onClick={handleExportData}
                  className="flex flex-col items-center justify-center p-2 border-2 border-gray-900 rounded hover:bg-gray-50 transition-all text-center text-xs font-bold"
                  title="Exportar datos a un archivo JSON"
                >
                  <FileDown className="w-4 h-4 mb-1 text-app-purple" />
                  <span>Exportar</span>
                </button>

                <label
                  id="import-data-label"
                  className="flex flex-col items-center justify-center p-2 border-2 border-gray-900 rounded hover:bg-gray-50 transition-all text-center cursor-pointer text-xs font-bold"
                  title="Importar datos desde un archivo JSON"
                >
                  <FileUp className="w-4 h-4 mb-1 text-emerald-600" />
                  <span>Importar</span>
                  <input type="file" accept=".json" onChange={handleImportData} className="hidden" />
                </label>
              </div>

              <div className="text-center pt-2">
                <p className="text-[10px] text-gray-400 font-bold">ChefCost Pro v1.2</p>
                <p className="text-[9px] text-gray-400">Hecho para panaderos y cocineros</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SETTINGS OVERLAY / MODAL */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setShowSettings(false)}>
          <div
            className="w-full max-w-md bg-white text-gray-900 rounded border-4 border-gray-900 p-6 shadow-brutal animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center pb-4 border-b-2 border-gray-200 mb-5">
              <h3 className="font-sans text-xl font-black uppercase tracking-tight flex items-center gap-2 text-gray-900">
                <Settings className="w-5 h-5 text-app-purple" />
                Configuración General
              </h3>
              <button onClick={() => setShowSettings(false)} className="p-1 hover:bg-gray-100 border-2 border-transparent active:border-gray-900 rounded">
                <X className="w-5 h-5 stroke-[2.5]" />
              </button>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1.5">Tarifa por Hora por Defecto ($/hora)</label>
                <input
                  id="settings-hourly-rate-input"
                  type="number"
                  value={laborHourlyRate}
                  onChange={(e) => {
                    const val = Math.max(0, parseFloat(e.target.value) || 0);
                    setLaborHourlyRate(val);
                    setDefaultHourlyRate(val);
                  }}
                  className="w-full bg-gray-50 border-2 border-gray-900 p-2 font-bold text-gray-900 rounded"
                />
                <p className="text-xs text-gray-500 mt-1">Se usará como valor inicial para los cálculos de mano de obra basados en horas.</p>
              </div>

              <div className="p-3 bg-app-peach/20 border-2 border-app-peach rounded text-xs text-gray-800 space-y-1.5 font-medium">
                <p className="font-bold flex items-center gap-1"><Info className="w-4 h-4 text-app-purple" /> Información de Fórmulas:</p>
                <p><strong>Costo Producción</strong> = Ingredientes + Mano de Obra.</p>
                <p><strong>Mano de Obra (2x Excel)</strong> = Multiplica los ingredientes por el factor indicado para estimar el trabajo indirecto o mermas.</p>
                <p><strong>Precio Venta Sugerido</strong> = Costo de Producción + Margen de Ganancia.</p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                id="reset-factory-btn"
                onClick={() => {
                  if (confirm('¿Estás seguro de que quieres restablecer todos los datos? Se borrará el historial y los ingredientes personalizados.')) {
                    localStorage.removeItem('chefcost_ingredients');
                    localStorage.removeItem('chefcost_calculations');
                    setIngredients(INITIAL_INGREDIENTS);
                    setCalculations(INITIAL_CALCULATIONS);
                    setCalcItems([
                      { ingredientId: 'ing-1', quantity: 50 },
                      { ingredientId: 'ing-2', quantity: 300 }
                    ]);
                    setCalcName('Nuevo Cálculo de Torta');
                    setActiveCalculationId(null);
                    setShowSettings(false);
                    triggerNotification('Datos restaurados a valores de fábrica.', 'info');
                  }
                }}
                className="flex-1 py-2 px-3 border-2 border-rose-600 hover:bg-rose-50 text-rose-600 font-bold rounded text-xs transition-colors"
              >
                Restablecer Todo
              </button>
              <button
                id="save-settings-btn"
                onClick={() => setShowSettings(false)}
                className="flex-1 py-2 px-3 bg-gray-900 hover:bg-gray-800 text-white border-2 border-gray-900 font-bold rounded text-xs shadow-brutal-sm transition-all"
              >
                Guardar y Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MAIN CONTAINER */}
      <main className="flex-grow p-4 md:p-6 max-w-4xl mx-auto w-full">
        {/* HEADER RECIPE TITLE / QUICK ACTIONS */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div className="flex-1">
            {activeTab === 'calculator' ? (
              <div className="flex items-center gap-2 group">
                <Edit2 className="w-5 h-5 text-app-purple shrink-0" />
                <input
                  id="recipe-name-input"
                  type="text"
                  value={calcName}
                  onChange={(e) => setCalcName(e.target.value)}
                  placeholder="Nombre de la Receta (ej. Torta de Tres Leches)"
                  className="font-sans text-xl md:text-2xl font-black bg-transparent border-b-2 border-transparent hover:border-gray-400 focus:border-app-purple focus:outline-none text-gray-900 py-1 w-full rounded-none tracking-tight transition-all"
                />
              </div>
            ) : activeTab === 'history' ? (
              <div>
                <h2 className="font-sans text-xl md:text-2xl font-black text-gray-900 flex items-center gap-2 uppercase tracking-tight">
                  <History className="w-6 h-6 text-app-purple stroke-[2.5]" />
                  Historial de Cálculos
                </h2>
                <p className="text-xs text-gray-600 mt-1 font-medium">Consulta, edita o elimina recetas y presupuestos guardados.</p>
              </div>
            ) : (
              <div>
                <h2 className="font-sans text-xl md:text-2xl font-black text-gray-900 flex items-center gap-2 uppercase tracking-tight">
                  <Apple className="w-6 h-6 text-app-purple stroke-[2.5]" />
                  Base de Ingredientes
                </h2>
                <p className="text-xs text-gray-600 mt-1 font-medium">Configura el costo de compra de tus materias primas para tus recetas.</p>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            {activeTab === 'calculator' && (
              <>
                <button
                  id="reset-calculator-btn"
                  onClick={handleResetCalculator}
                  className="p-2 border-2 border-gray-900 rounded-md hover:bg-gray-100 transition-all text-gray-800 flex items-center gap-1.5 text-xs font-bold bg-white shadow-brutal-sm active:translate-x-0.5 active:translate-y-0.5 active:shadow-none"
                  title="Reiniciar Calculadora"
                >
                  <RotateCcw className="w-4 h-4 text-app-purple stroke-[2.5]" />
                  <span>Limpiar</span>
                </button>

                <button
                  id="save-recipe-top-btn"
                  onClick={handleSaveCalculation}
                  className="py-2 px-4 bg-app-peach text-gray-900 border-2 border-gray-900 font-bold rounded-md shadow-brutal-sm hover:bg-white hover:translate-x-0.5 hover:translate-y-0.5 active:translate-x-1 active:translate-y-1 active:shadow-none transition-all flex items-center gap-2 text-xs"
                >
                  <Save className="w-4 h-4 text-gray-900 stroke-[2.5]" />
                  <span>{activeCalculationId ? 'Actualizar' : 'Guardar'}</span>
                </button>
              </>
            )}

            {activeTab === 'ingredients' && (
              <button
                id="add-dict-ing-btn"
                onClick={handleOpenAddDictIngredient}
                className="py-2 px-4 bg-app-peach text-gray-900 border-2 border-gray-900 font-bold rounded-md shadow-brutal-sm hover:bg-white active:translate-x-0.5 active:translate-y-0.5 transition-all flex items-center gap-2 text-xs"
              >
                <Plus className="w-4 h-4 text-gray-900 stroke-[2.5]" />
                <span>Nuevo Ingrediente</span>
              </button>
            )}
          </div>
        </div>

        {/* ==================== TAB: CALCULATOR ==================== */}
        {activeTab === 'calculator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* LEFT COLUMN: INPUT MODULES */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* 1. INGREDIENTS / MATERIAS PRIMAS */}
              <section id="ingredients-section" className="bg-app-card-dark rounded-md p-4 md:p-5 border-2 border-gray-900 shadow-brutal-sm relative text-slate-800">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-sans font-bold text-base md:text-lg text-slate-900 flex items-center gap-2 uppercase tracking-tight">
                    <span className="p-1.5 bg-app-purple/10 text-app-purple rounded border border-app-purple/20">
                      <Utensils className="w-4 h-4 text-app-purple" />
                    </span>
                    1. Materias Primas
                  </h3>

                  <button
                    id="add-ingredient-to-recipe-btn"
                    onClick={() => {
                      setSearchIngredientQuery('');
                      setShowAddIngredientDrawer(true);
                    }}
                    className="bg-app-peach text-gray-900 font-black py-1.5 px-3.5 rounded border-2 border-gray-900 shadow-brutal-sm hover:bg-white active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all flex items-center gap-1.5 text-xs"
                  >
                    <Plus className="w-3.5 h-3.5 stroke-[3]" />
                    <span>Añadir</span>
                  </button>
                </div>

                {/* Recipe items list */}
                {calcItems.length === 0 ? (
                  <div className="text-center py-10 border-2 border-dashed border-gray-300 rounded bg-slate-50">
                    <Scale className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm font-bold text-slate-600">No hay ingredientes en la receta</p>
                    <p className="text-xs text-slate-400 mt-1">Haz clic en '+ Añadir' para agregar ingredientes.</p>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-200">
                    {calcItems.map((item, idx) => {
                      const ing = ingredients.find(i => i.id === item.ingredientId);
                      if (!ing) return null;
                      const itemCost = item.quantity * ing.pricePerUnit;

                      return (
                        <div key={item.ingredientId} className="flex items-center justify-between gap-3 py-3.5 first:pt-0 last:pb-0">
                          <div className="flex-1 min-w-0">
                            <p className="font-bold text-slate-900 truncate text-sm capitalize">{ing.name}</p>
                            <p className="text-xs text-slate-500 font-medium">
                              {formatCurrency(ing.pricePerUnit * (ing.purchaseUnit === 'u' ? 1 : 1000))} / {ing.purchaseUnit === 'u' ? 'u' : 'kg'}
                              <span className="mx-1 text-slate-300">•</span>
                              <span className="text-slate-400">{formatCurrency(ing.pricePerUnit)}/g</span>
                            </p>
                          </div>

                          <div className="flex items-center gap-2">
                            {/* Quantity Input with embedded unit */}
                            <div className="relative w-24">
                              <input
                                id={`ingredient-qty-${item.ingredientId}`}
                                type="number"
                                value={item.quantity || ''}
                                onChange={(e) => handleUpdateItemQuantity(item.ingredientId, parseFloat(e.target.value) || 0)}
                                className="w-full bg-slate-50 border-2 border-gray-900 text-right pr-7 pl-2 py-1.5 rounded font-black text-slate-900 text-sm focus:outline-none focus:border-app-purple focus:shadow-brutal-sm"
                                placeholder="0"
                                aria-label={`Cantidad de ${ing.name}`}
                              />
                              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-slate-500 font-bold pointer-events-none select-none">
                                {getUnitName(ing.purchaseUnit === 'kg' ? 'g' : ing.purchaseUnit === 'L' ? 'ml' : ing.purchaseUnit)}
                              </span>
                            </div>

                            {/* Cost display */}
                            <p className="font-black text-slate-900 w-14 text-right text-sm">
                              {formatCurrency(itemCost)}
                            </p>

                            {/* Remove button */}
                            <button
                              id={`remove-ingredient-btn-${item.ingredientId}`}
                              onClick={() => handleRemoveItemFromRecipe(item.ingredientId)}
                              className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-slate-100 rounded transition-colors"
                              title="Eliminar ingrediente"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>

              {/* 2. LABOR / MANO DE OBRA */}
              <section id="labor-section" className="bg-app-card-dark rounded-md p-4 md:p-5 border-2 border-gray-900 shadow-brutal-sm text-slate-800">
                <h3 className="font-sans font-bold text-base md:text-lg text-slate-900 flex items-center gap-2 uppercase tracking-tight mb-4">
                  <span className="p-1.5 bg-app-purple/10 text-app-purple rounded border border-app-purple/20">
                    <Clock className="w-4 h-4 text-app-purple" />
                  </span>
                  2. Mano de Obra
                </h3>

                {/* Labor options list - Brutalist Radios */}
                <div className="space-y-2.5 mb-5">
                  <label id="labor-fixed-label" className={`flex items-center cursor-pointer group p-2.5 border-2 rounded select-none transition-all ${laborMode === 'fixed' ? 'border-gray-900 bg-app-purple/5' : 'border-transparent bg-slate-50 hover:bg-slate-100'}`}>
                    <input
                      type="radio"
                      name="labor_mode"
                      value="fixed"
                      checked={laborMode === 'fixed'}
                      onChange={() => setLaborMode('fixed')}
                      className="w-5 h-5 accent-app-purple cursor-pointer border-2 border-gray-600 rounded bg-transparent mr-3 shrink-0"
                    />
                    <div className="flex-1">
                      <span className="font-bold text-sm text-slate-900 group-hover:text-app-purple transition-colors block">Monto Fijo Directo ($)</span>
                      <span className="text-[11px] text-slate-500 font-medium">Asignación directa de un valor fijo de mano de obra.</span>
                    </div>
                  </label>

                  <label id="labor-hourly-label" className={`flex items-center cursor-pointer group p-2.5 border-2 rounded select-none transition-all ${laborMode === 'hourly' ? 'border-gray-900 bg-app-purple/5' : 'border-transparent bg-slate-50 hover:bg-slate-100'}`}>
                    <input
                      type="radio"
                      name="labor_mode"
                      value="hourly"
                      checked={laborMode === 'hourly'}
                      onChange={() => setLaborMode('hourly')}
                      className="w-5 h-5 accent-app-purple cursor-pointer border-2 border-gray-600 rounded bg-transparent mr-3 shrink-0"
                    />
                    <div className="flex-1">
                      <span className="font-bold text-sm text-slate-900 group-hover:text-app-purple transition-colors block">Por Horas (Horas x Tarifa)</span>
                      <span className="text-[11px] text-slate-500 font-medium">Calcula en base al tiempo empleado y costo de hora chef.</span>
                    </div>
                  </label>

                  <label id="labor-multiplier-label" className={`flex items-center cursor-pointer group p-2.5 border-2 rounded select-none transition-all ${laborMode === 'multiplier' ? 'border-gray-900 bg-app-purple/5' : 'border-transparent bg-slate-50 hover:bg-slate-100'}`}>
                    <input
                      type="radio"
                      name="labor_mode"
                      value="multiplier"
                      checked={laborMode === 'multiplier'}
                      onChange={() => setLaborMode('multiplier')}
                      className="w-5 h-5 accent-app-purple cursor-pointer border-2 border-gray-600 rounded bg-transparent mr-3 shrink-0"
                    />
                    <div className="flex-1">
                      <span className="font-bold text-sm text-slate-900 group-hover:text-app-purple transition-colors block">Multiplicador de Materia Prima (2x Excel)</span>
                      <span className="text-[11px] text-slate-500 font-medium">Utilizado frecuentemente para duplicar ingredientes (Merma y Gas).</span>
                    </div>
                  </label>

                  <label id="labor-percentage-label" className={`flex items-center cursor-pointer group p-2.5 border-2 rounded select-none transition-all ${laborMode === 'percentage' ? 'border-gray-900 bg-app-purple/5' : 'border-transparent bg-slate-50 hover:bg-slate-100'}`}>
                    <input
                      type="radio"
                      name="labor_mode"
                      value="percentage"
                      checked={laborMode === 'percentage'}
                      onChange={() => setLaborMode('percentage')}
                      className="w-5 h-5 accent-app-purple cursor-pointer border-2 border-gray-600 rounded bg-transparent mr-3 shrink-0"
                    />
                    <div className="flex-1">
                      <span className="font-bold text-sm text-slate-900 group-hover:text-app-purple transition-colors block">% sobre Materia Prima</span>
                      <span className="text-[11px] text-slate-500 font-medium">Asigna un porcentaje del costo total de ingredientes.</span>
                    </div>
                  </label>
                </div>

                {/* Sub-inputs dependent on selected option */}
                {laborMode === 'fixed' && (
                  <div className="border-2 border-gray-900 rounded-md p-4 bg-white relative mt-2 shadow-brutal-sm">
                    <span className="absolute -top-3 left-3 bg-white px-1.5 text-[11px] text-slate-500 font-bold">Monto Fijo de Trabajo ($)</span>
                    <div className="flex items-center">
                      <span className="font-bold text-slate-500 mr-2">$</span>
                      <input
                        id="labor-fixed-input"
                        type="number"
                        value={laborFixedAmount || ''}
                        onChange={(e) => setLaborFixedAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                        className="bg-transparent border-none p-0 text-lg font-black text-slate-900 w-full focus:outline-none"
                        placeholder="0"
                      />
                    </div>
                  </div>
                )}

                {laborMode === 'hourly' && (
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div className="border-2 border-gray-900 rounded-md p-4 bg-white relative shadow-brutal-sm">
                      <span className="absolute -top-3 left-3 bg-white px-1.5 text-[11px] text-slate-500 font-bold">Horas</span>
                      <input
                        id="labor-hourly-hours-input"
                        type="number"
                        step="0.1"
                        value={laborHourlyHours || ''}
                        onChange={(e) => setLaborHourlyHours(Math.max(0, parseFloat(e.target.value) || 0))}
                        className="bg-transparent border-none p-0 text-lg font-black text-slate-900 w-full focus:outline-none text-right pr-4"
                        placeholder="0.0"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">hrs</span>
                    </div>

                    <div className="border-2 border-gray-900 rounded-md p-4 bg-white relative shadow-brutal-sm">
                      <span className="absolute -top-3 left-3 bg-white px-1.5 text-[11px] text-slate-500 font-bold">Tarifa ($/hr)</span>
                      <div className="flex items-center">
                        <span className="font-bold text-slate-500 mr-1">$</span>
                        <input
                          id="labor-hourly-rate-input"
                          type="number"
                          value={laborHourlyRate || ''}
                          onChange={(e) => setLaborHourlyRate(Math.max(0, parseFloat(e.target.value) || 0))}
                          className="bg-transparent border-none p-0 text-lg font-black text-slate-900 w-full focus:outline-none"
                          placeholder="0"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {laborMode === 'multiplier' && (
                  <div className="border-2 border-gray-900 rounded-md p-4 bg-white relative mt-2 shadow-brutal-sm">
                    <span className="absolute -top-3 left-3 bg-white px-1.5 text-[11px] text-slate-500 font-bold">Multiplicador (ej: 2x duplica costo ingredientes)</span>
                    <div className="flex items-center">
                      <input
                        id="labor-multiplier-input"
                        type="number"
                        step="0.1"
                        value={laborMultiplier || ''}
                        onChange={(e) => setLaborMultiplier(Math.max(0, parseFloat(e.target.value) || 0))}
                        className="bg-transparent border-none p-0 text-lg font-black text-slate-900 w-full focus:outline-none"
                        placeholder="2.0"
                      />
                      <span className="font-black text-app-purple text-lg">x</span>
                    </div>
                  </div>
                )}

                {laborMode === 'percentage' && (
                  <div className="border-2 border-gray-900 rounded-md p-4 bg-white relative mt-2 shadow-brutal-sm">
                    <span className="absolute -top-3 left-3 bg-white px-1.5 text-[11px] text-slate-500 font-bold">Porcentaje (%)</span>
                    <div className="flex items-center">
                      <input
                        id="labor-percentage-input"
                        type="number"
                        value={laborPercentage || ''}
                        onChange={(e) => setLaborPercentage(Math.max(0, parseFloat(e.target.value) || 0))}
                        className="bg-transparent border-none p-0 text-lg font-black text-slate-900 w-full focus:outline-none text-right pr-6"
                        placeholder="0"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 font-bold text-slate-500">%</span>
                    </div>
                  </div>
                )}

                <div className="flex justify-between items-center mt-4 border-t border-slate-200 pt-4 font-bold">
                  <p className="text-slate-500 text-sm">Total Mano de Obra:</p>
                  <p className="text-app-purple font-black text-base md:text-lg">{formatCurrency(computations.laborCost)}</p>
                </div>
              </section>

              {/* 2.5 COSTOS FIJOS / FIXED OVERHEAD */}
              <section id="fixed-costs-section" className="bg-app-card-dark rounded-md p-4 md:p-5 border-2 border-gray-900 shadow-brutal-sm text-slate-800">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-sans font-bold text-base md:text-lg text-slate-900 flex items-center gap-2 uppercase tracking-tight">
                    <span className="p-1.5 bg-app-purple/10 text-app-purple rounded border border-app-purple/20">
                      <Percent className="w-4 h-4 text-app-purple" />
                    </span>
                    2.5. Costos Fijos (Indirectos)
                  </h3>
                  <button
                    id="add-fixed-cost-btn"
                    type="button"
                    onClick={() => handleAddFixedCostItem('Nuevo Gasto', 1000)}
                    className="bg-app-peach text-gray-900 font-black py-1.5 px-3.5 rounded border-2 border-gray-900 shadow-brutal-sm hover:bg-white active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all flex items-center gap-1.5 text-xs"
                  >
                    <Plus className="w-3.5 h-3.5 stroke-[3]" />
                    <span>Añadir</span>
                  </button>
                </div>

                <p className="text-xs text-slate-500 mb-4 font-medium">
                  Costos que no varían con cada porción (ej: gas, packaging de caja, luz asignada, envío, etc.).
                </p>

                {calcFixedCosts.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded bg-slate-50">
                    <p className="text-sm font-bold text-slate-600">No hay costos fijos</p>
                    <p className="text-xs text-slate-400 mt-1">Haz clic en '+ Añadir' o usa un botón de abajo.</p>
                  </div>
                ) : (
                  <div className="space-y-3 mb-4">
                    {calcFixedCosts.map((item) => (
                      <div key={item.id} className="flex items-center gap-2">
                        <input
                          id={`fixed-cost-name-${item.id}`}
                          type="text"
                          value={item.name}
                          onChange={(e) => handleUpdateFixedCostItem(item.id, 'name', e.target.value)}
                          className="flex-1 bg-slate-50 border-2 border-gray-900 px-3 py-1.5 rounded font-bold text-slate-900 text-xs focus:outline-none focus:border-app-purple focus:shadow-brutal-sm"
                          placeholder="ej. Gas, Envase"
                        />
                        <div className="relative w-28">
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">$</span>
                          <input
                            id={`fixed-cost-amount-${item.id}`}
                            type="number"
                            value={item.amount || ''}
                            onChange={(e) => handleUpdateFixedCostItem(item.id, 'amount', parseFloat(e.target.value) || 0)}
                            className="w-full bg-slate-50 border-2 border-gray-900 text-right pr-3 pl-6 py-1.5 rounded font-black text-slate-900 text-xs focus:outline-none focus:border-app-purple focus:shadow-brutal-sm"
                            placeholder="0"
                          />
                        </div>
                        <button
                          id={`remove-fixed-cost-${item.id}`}
                          onClick={() => handleRemoveFixedCostItem(item.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-slate-100 rounded transition-colors"
                          title="Eliminar costo fijo"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Presets Grid */}
                <div className="space-y-2 pt-1">
                  <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider block">Pre-ajustes Rápidos:</span>
                  <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide flex-wrap">
                    {[
                      { name: 'Caja / Envase', amount: 800 },
                      { name: 'Gas / Energía', amount: 500 },
                      { name: 'Luz / Agua', amount: 1000 },
                      { name: 'Delivery / Envío', amount: 1500 },
                      { name: 'Decoraciones', amount: 600 }
                    ].map((preset, idx) => (
                      <button
                        key={idx}
                        id={`fc-preset-btn-${idx}`}
                        type="button"
                        onClick={() => {
                          setCalcFixedCosts([...calcFixedCosts, { id: `fc-p-${Date.now()}-${idx}`, name: preset.name, amount: preset.amount }]);
                          triggerNotification(`Costo fijo añadido: ${preset.name} (${formatCurrency(preset.amount)})`);
                        }}
                        className="bg-slate-50 border border-gray-300 hover:border-gray-900 rounded py-1 px-2.5 text-[10px] text-slate-700 font-bold hover:bg-slate-100 shrink-0 transition-all"
                      >
                        + {preset.name} ({formatCurrency(preset.amount)})
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex justify-between items-center mt-4 border-t border-slate-200 pt-4 font-bold">
                  <p className="text-slate-500 text-sm">Total Costos Fijos:</p>
                  <p className="text-app-purple font-black text-base md:text-lg">{formatCurrency(computations.fixedCostsTotal)}</p>
                </div>
              </section>

              {/* 3. MARGIN & PORTIONS / MARGEN Y PORCIONES */}
              <section id="margin-section" className="bg-app-card-dark rounded-md p-4 md:p-5 border-2 border-gray-900 shadow-brutal-sm text-slate-800">
                <h3 className="font-sans font-bold text-base md:text-lg text-slate-900 flex items-center gap-2 uppercase tracking-tight mb-4">
                  <span className="p-1.5 bg-app-purple/10 text-app-purple rounded border border-app-purple/20">
                    <Percent className="w-4 h-4 text-app-purple" />
                  </span>
                  3. Margen de Ganancia y Porciones
                </h3>

                <div className="grid grid-cols-2 gap-4">
                  {/* Ganancia % */}
                  <div className="border-2 border-gray-900 rounded-md p-4 bg-white relative shadow-brutal-sm">
                    <span className="absolute -top-3 left-3 bg-white px-1.5 text-[11px] text-slate-500 font-bold">Ganancia (%)</span>
                    <div className="flex items-center">
                      <input
                        id="profit-margin-input"
                        type="number"
                        value={margin || ''}
                        onChange={(e) => setMargin(Math.max(0, parseFloat(e.target.value) || 0))}
                        className="bg-transparent border-none p-0 text-lg font-black text-slate-900 w-full focus:outline-none"
                        placeholder="50"
                      />
                      <span className="font-bold text-slate-500">%</span>
                    </div>
                  </div>

                  {/* Porciones */}
                  <div className="border-2 border-gray-900 rounded-md p-4 bg-white relative shadow-brutal-sm">
                    <span className="absolute -top-3 left-3 bg-white px-1.5 text-[11px] text-slate-500 font-bold">Porciones</span>
                    <input
                      id="portions-input"
                      type="number"
                      value={portions || ''}
                      onChange={(e) => setPortions(Math.max(1, parseInt(e.target.value) || 1))}
                      className="bg-transparent border-none p-0 text-lg font-black text-slate-900 w-full focus:outline-none text-right pr-4"
                      placeholder="12"
                    />
                  </div>
                </div>

                {/* Preset Buttons */}
                <div className="flex gap-2 mt-4 overflow-x-auto pb-1 scrollbar-hide">
                  {[25, 50, 75, 100].map((p) => (
                    <button
                      key={p}
                      id={`preset-margin-btn-${p}`}
                      onClick={() => {
                        setMargin(p);
                        triggerNotification(`Margen de ganancia fijado en ${p}%`, 'info');
                      }}
                      className={`border-2 border-gray-900 rounded py-1 px-4 text-xs font-bold transition-all shrink-0 ${
                        margin === p
                          ? 'bg-app-peach text-gray-900 border-gray-900 shadow-brutal-sm scale-95'
                          : 'bg-white text-slate-800 hover:bg-slate-100 shadow-brutal-sm active:translate-y-0.5'
                      }`}
                    >
                      {p}%
                    </button>
                  ))}
                  <button
                    id="preset-margin-btn-150"
                    onClick={() => {
                      setMargin(150);
                      triggerNotification('Margen de ganancia fijado en 150%', 'info');
                    }}
                    className={`border-2 border-gray-900 rounded py-1 px-4 text-xs font-bold transition-all shrink-0 ${
                      margin === 150
                        ? 'bg-app-peach text-gray-900 border-gray-900 shadow-brutal-sm scale-95'
                        : 'bg-white text-slate-800 hover:bg-slate-100 shadow-brutal-sm active:translate-y-0.5'
                    }`}
                  >
                    150%
                  </button>
                </div>
              </section>
            </div>

            {/* RIGHT COLUMN: REAL-TIME SUMMARY CARD (STICKY) */}
            <div className="lg:col-span-5 lg:sticky lg:top-24 space-y-4">
              <section id="summary-card" className="bg-app-purple text-white rounded-md p-5 md:p-6 shadow-brutal border-4 border-gray-900 relative overflow-hidden">
                {/* Decorative Bauhaus shapes */}
                <div className="absolute right-0 top-0 w-24 h-24 bg-white/5 rounded-full -mr-10 -mt-10 pointer-events-none" />
                
                <h3 className="text-xs font-black uppercase tracking-widest mb-3 text-white/70">Resumen del Cálculo</h3>

                <div className="space-y-4">
                  {/* Suggested Selling Price */}
                  <div>
                    <p className="text-[11px] font-black uppercase tracking-widest text-white/80 mb-0.5">Precio Venta Sugerido</p>
                    <p className="text-4xl md:text-5xl font-black text-app-peach tracking-tight drop-shadow">
                      {formatCurrency(computations.suggestedPrice)}
                    </p>
                  </div>

                  {/* Price Per Portion */}
                  <div className="bg-black/20 rounded p-3 border border-white/10 flex justify-between items-center">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-white/70">Por Porción</p>
                      <p className="text-[11px] text-gray-300 font-bold">Rendimiento: {portions} porciones</p>
                    </div>
                    <p className="text-lg md:text-xl font-black text-white tracking-tight text-right">
                      {formatCurrency(computations.pricePerPortion)}
                    </p>
                  </div>

                  <hr className="border-t-2 border-white/10 my-1" />

                  {/* 4 Grid Stats */}
                  <div className="grid grid-cols-4 gap-1 text-center">
                    <div className="bg-black/15 rounded p-1.5 border border-white/5">
                      <p className="text-[8px] uppercase font-bold text-white/65 tracking-wider">Costo Prod.</p>
                      <p className="font-black text-[10px] md:text-xs mt-0.5 text-white">{formatCurrency(computations.productionCost)}</p>
                    </div>

                    <div className="bg-black/15 rounded p-1.5 border border-white/5">
                      <p className="text-[8px] uppercase font-bold text-white/65 tracking-wider">Materia P.</p>
                      <p className="font-black text-[10px] md:text-xs mt-0.5 text-white">{formatCurrency(computations.rawMaterialsCost)}</p>
                    </div>
                    
                    <div className="bg-black/15 rounded p-1.5 border border-white/5">
                      <p className="text-[8px] uppercase font-bold text-white/65 tracking-wider">Mano Obra</p>
                      <p className="font-black text-[10px] md:text-xs mt-0.5 text-white">{formatCurrency(computations.laborCost)}</p>
                    </div>

                    <div className="bg-black/15 rounded p-1.5 border border-white/5">
                      <p className="text-[8px] uppercase font-bold text-white/65 tracking-wider">Costos Fij.</p>
                      <p className="font-black text-[10px] md:text-xs mt-0.5 text-orange-200">{formatCurrency(computations.fixedCostsTotal)}</p>
                    </div>
                  </div>
                </div>
              </section>

              {/* SAVE CALCULATION FLOATING-LIKE CARD */}
              <div className="p-4 bg-app-card-dark rounded-md border-2 border-gray-800 flex flex-col md:flex-row items-center gap-3 justify-between">
                <div>
                  <h4 className="font-bold text-sm text-white">{activeCalculationId ? 'Edición Activa' : '¿Terminaste el cálculo?'}</h4>
                  <p className="text-xs text-gray-400">Guarda este registro para consultarlo en el historial.</p>
                </div>
                
                <button
                  id="save-calculation-btn-card"
                  onClick={handleSaveCalculation}
                  className="w-full md:w-auto bg-app-peach text-gray-900 font-black py-2.5 px-6 rounded border-2 border-gray-900 shadow-brutal hover:bg-white active:translate-x-0.5 active:translate-y-0.5 active:shadow-brutal-sm transition-all flex items-center justify-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  <span>{activeCalculationId ? 'Actualizar Cálculo' : 'Guardar Cálculo'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB: HISTORY ==================== */}
        {activeTab === 'history' && (
          <div className="space-y-4">
            {calculations.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-md border-2 border-gray-900 shadow-brutal-sm">
                <BookOpen className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                <h3 className="text-lg font-bold text-slate-900">Tu Historial está vacío</h3>
                <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1 font-medium">
                  Aquí aparecerán todas las recetas que calcules y guardes. Regresa a la calculadora para crear tu primera torta.
                </p>
                <button
                  id="empty-history-back-btn"
                  onClick={() => setActiveTab('calculator')}
                  className="mt-5 py-2 px-6 bg-app-peach text-gray-900 border-2 border-gray-900 font-bold rounded shadow-brutal-sm hover:bg-white active:translate-y-0.5 active:shadow-none transition-all text-sm inline-flex items-center gap-2"
                >
                  <Calculator className="w-4 h-4 text-gray-900" />
                  <span>Ir a la Calculadora</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {calculations.map((calc) => (
                  <div
                    key={calc.id}
                    id={`history-card-${calc.id}`}
                    onClick={() => handleLoadCalculation(calc)}
                    className="bg-white rounded-md border-2 border-gray-900 hover:border-app-purple p-4 cursor-pointer transition-all hover:-translate-y-0.5 shadow-brutal-sm hover:shadow-brutal group relative"
                  >
                    {/* Date label */}
                    <span className="absolute top-3 right-3 text-[10px] text-slate-500 font-bold">{calc.date}</span>

                    <h3 className="font-sans font-black text-base text-app-purple capitalize mb-1 truncate pr-16 group-hover:text-slate-900 transition-colors">
                      {calc.name}
                    </h3>

                    <div className="flex justify-between items-end mt-4">
                      <div className="space-y-1">
                        <p className="text-[10px] uppercase text-slate-500 font-bold">Precio Sugerido ({calc.portions} p.)</p>
                        <p className="text-xl font-black text-slate-900">{formatCurrency(calc.suggestedPrice)}</p>
                        <p className="text-xs text-slate-500 font-bold">Porción: {formatCurrency(calc.suggestedPrice / calc.portions)}</p>
                      </div>

                      <div className="text-right space-y-1 text-xs">
                        <p className="text-slate-600 font-medium">Prod: <span className="font-bold text-slate-950">{formatCurrency(calc.productionCost)}</span></p>
                        <p className="text-slate-600 font-medium">Margen: <span className="font-black text-emerald-600">+{calc.margin}%</span></p>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-200 flex justify-between items-center text-xs">
                      <span className="text-slate-500 font-medium flex items-center gap-1.5 flex-wrap">
                        <Utensils className="w-3.5 h-3.5 text-app-purple" /> {calc.items.length} ing.
                        {calc.fixedCosts && calc.fixedCosts.length > 0 && (
                          <>
                            <span className="text-slate-300">•</span>
                            <span>{calc.fixedCosts.length} fijos ({formatCurrency(calc.fixedCostsTotal || 0)})</span>
                          </>
                        )}
                      </span>
                      
                      <div className="flex gap-2">
                        <button
                          id={`history-delete-btn-${calc.id}`}
                          onClick={(e) => handleDeleteCalculation(calc.id, e)}
                          className="text-slate-400 hover:text-rose-600 p-1 rounded hover:bg-slate-100 transition-all"
                          title="Eliminar del historial"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <span className="p-1 text-app-purple group-hover:translate-x-1 transition-transform">
                          <ChevronRight className="w-4 h-4 stroke-[2.5]" />
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ==================== TAB: INGREDIENTS DICTIONARY ==================== */}
        {activeTab === 'ingredients' && (
          <div className="space-y-4">
            
            {/* SEARCH & ADD CONTAINER */}
            <div className="bg-white p-4 rounded-md border-2 border-gray-900 shadow-brutal-sm flex flex-col md:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-5 h-5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="ingredient-search-input"
                  type="text"
                  placeholder="Buscar ingredientes o categorías (ej. Harina, Lácteos)..."
                  value={searchIngredientQuery}
                  onChange={(e) => setSearchIngredientQuery(e.target.value)}
                  className="w-full bg-slate-50 border-2 border-gray-900 pl-10 pr-4 py-2 rounded text-sm text-slate-900 focus:outline-none focus:border-app-purple focus:shadow-brutal-sm"
                />
              </div>

              <button
                id="add-dict-ing-bar-btn"
                onClick={handleOpenAddDictIngredient}
                className="bg-app-peach text-gray-900 font-black py-2 px-5 rounded border-2 border-gray-900 shadow-brutal hover:bg-white active:translate-x-0.5 active:translate-y-0.5 active:shadow-brutal-sm transition-all flex items-center justify-center gap-2 text-sm shrink-0"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>Añadir Ingrediente</span>
              </button>
            </div>

            {/* INGREDIENTS LIST GRID */}
            {filteredIngredients.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-md border-2 border-gray-900 shadow-brutal-sm">
                <Search className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                <h3 className="text-lg font-bold text-slate-900">No se encontraron ingredientes</h3>
                <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1 font-medium">
                  Intenta cambiar el término de búsqueda o crea un nuevo ingrediente usando el botón superior.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredIngredients.map((ing) => (
                  <div
                    key={ing.id}
                    id={`dict-ingredient-card-${ing.id}`}
                    className="bg-white rounded-md border-2 border-gray-900 hover:border-app-purple shadow-brutal-sm p-4 relative group"
                  >
                    {/* Category pill */}
                    <span className="absolute top-3 right-3 text-[9px] bg-app-purple/10 text-app-purple px-2 py-0.5 border border-app-purple/20 rounded font-bold uppercase">
                      {ing.category}
                    </span>

                    <h3 className="font-sans font-black text-base text-slate-900 capitalize pr-16 truncate mb-1">
                      {ing.name}
                    </h3>

                    <div className="space-y-1.5 mt-3">
                      <div>
                        <p className="text-[10px] text-slate-500 font-bold uppercase">Precio por Unidad Base</p>
                        <p className="text-lg font-black text-app-purple">
                          {formatCurrency(ing.pricePerUnit)} <span className="text-xs text-slate-500 font-normal">/ g</span>
                        </p>
                      </div>

                      <div className="text-xs text-slate-600 font-medium">
                        <p>Compra: <span className="font-bold text-slate-900">{formatCurrency(ing.purchasePrice)}</span> por <span className="font-bold text-slate-900">{ing.purchaseQuantity} {ing.purchaseUnit}</span></p>
                        {/* If unit is g or ml, show clear price per kg/L */}
                        {(ing.purchaseUnit === 'g' || ing.purchaseUnit === 'ml') && (
                          <p className="mt-0.5 text-slate-500">
                            Equivale a: <span className="font-bold text-slate-700">{formatCurrency(ing.pricePerUnit * 1000)}</span> por {ing.purchaseUnit === 'g' ? 'kg' : 'L'}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-200 flex justify-end gap-1.5">
                      <button
                        id={`dict-ingredient-edit-btn-${ing.id}`}
                        onClick={(e) => handleOpenEditDictIngredient(ing, e)}
                        className="text-xs font-bold py-1 px-2.5 border-2 border-gray-900 rounded hover:bg-slate-100 text-slate-800 transition-all flex items-center gap-1 bg-white shadow-brutal-sm active:translate-y-0.5"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Editar</span>
                      </button>

                      <button
                        id={`dict-ingredient-delete-btn-${ing.id}`}
                        onClick={(e) => handleDeleteDictIngredient(ing.id, e)}
                        className="text-xs font-bold py-1 px-2.5 border-2 border-transparent text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded transition-all flex items-center gap-1"
                        title="Eliminar ingrediente de la base"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* ==================== BOTTOM TAB BAR (NAVBAR) ==================== */}
      <nav id="bottom-nav" className="fixed bottom-0 left-0 w-full z-40 bg-white h-20 border-t-4 border-gray-900 md:hidden flex justify-around items-stretch select-none">
        <button
          id="tab-calculator-btn"
          onClick={() => setActiveTab('calculator')}
          className={`flex flex-col items-center justify-center w-1/3 py-2 px-1 transition-all text-center ${
            activeTab === 'calculator'
              ? 'bg-app-peach/30 text-gray-900 border-t-4 border-app-purple'
              : 'text-gray-500 hover:bg-gray-50'
          }`}
          aria-label="Ir a la Calculadora"
        >
          <Calculator className={`w-6 h-6 ${activeTab === 'calculator' ? 'text-app-purple fill-current stroke-[2.5]' : ''}`} />
          <span className="font-sans text-[10px] font-black uppercase tracking-tight mt-1">Calculadora</span>
        </button>

        <button
          id="tab-history-btn"
          onClick={() => setActiveTab('history')}
          className={`flex flex-col items-center justify-center w-1/3 py-2 px-1 transition-all text-center ${
            activeTab === 'history'
              ? 'bg-app-peach/30 text-gray-900 border-t-4 border-app-purple'
              : 'text-gray-500 hover:bg-gray-50'
          }`}
          aria-label="Ir al Historial"
        >
          <History className={`w-6 h-6 ${activeTab === 'history' ? 'text-app-purple stroke-[2.5]' : ''}`} />
          <span className="font-sans text-[10px] font-black uppercase tracking-tight mt-1">Historial</span>
        </button>

        <button
          id="tab-ingredients-btn"
          onClick={() => setActiveTab('ingredients')}
          className={`flex flex-col items-center justify-center w-1/3 py-2 px-1 transition-all text-center ${
            activeTab === 'ingredients'
              ? 'bg-app-peach/30 text-gray-900 border-t-4 border-app-purple'
              : 'text-gray-500 hover:bg-gray-50'
          }`}
          aria-label="Ir a la Base de Ingredientes"
        >
          <Apple className={`w-6 h-6 ${activeTab === 'ingredients' ? 'text-app-purple fill-current stroke-[2.5]' : ''}`} />
          <span className="font-sans text-[10px] font-black uppercase tracking-tight mt-1">Ingredientes</span>
        </button>
      </nav>

      {/* DESKTOP FOOTER / NAVIGATION */}
      <footer className="hidden md:block border-t-2 border-slate-200 mt-12 py-6 bg-slate-50 text-slate-500 text-xs font-bold text-center">
        <div className="max-w-4xl mx-auto px-4 flex justify-between items-center">
          <p>© 2026 ChefCost Pro. Diseñado con precisión y cariño para cocinas profesionales.</p>
          <div className="flex gap-4">
            <button id="footer-calculator" onClick={() => setActiveTab('calculator')} className={`hover:text-app-purple ${activeTab === 'calculator' ? 'text-app-purple font-black' : ''}`}>Calculadora</button>
            <button id="footer-history" onClick={() => setActiveTab('history')} className={`hover:text-app-purple ${activeTab === 'history' ? 'text-app-purple font-black' : ''}`}>Historial</button>
            <button id="footer-ingredients" onClick={() => setActiveTab('ingredients')} className={`hover:text-app-purple ${activeTab === 'ingredients' ? 'text-app-purple font-black' : ''}`}>Ingredientes</button>
          </div>
        </div>
      </footer>

      {/* ==================== DRAWER: SEARCH & ADD INGREDIENT TO RECIPE ==================== */}
      {showAddIngredientDrawer && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={() => setShowAddIngredientDrawer(false)}>
          <div
            className="w-full max-w-lg bg-white text-gray-900 rounded-t-xl sm:rounded-md border-t-4 sm:border-4 border-gray-900 p-5 shadow-brutal flex flex-col max-h-[85vh] sm:max-h-[75vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center pb-3 border-b-2 border-gray-200 mb-4 shrink-0">
              <h3 className="font-sans text-lg font-black uppercase tracking-tight text-gray-900 flex items-center gap-1.5">
                <Plus className="w-5 h-5 text-app-purple stroke-[3]" />
                Añadir Ingrediente a Receta
              </h3>
              <button onClick={() => setShowAddIngredientDrawer(false)} className="p-1 hover:bg-gray-100 border-2 border-transparent active:border-gray-900 rounded">
                <X className="w-5 h-5 stroke-[2.5]" />
              </button>
            </div>

            {/* Quick search input */}
            <div className="relative mb-4 shrink-0">
              <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="drawer-search-input"
                type="text"
                placeholder="Buscar ingrediente (ej. azúcar, mantequilla)..."
                value={searchIngredientQuery}
                onChange={(e) => setSearchIngredientQuery(e.target.value)}
                className="w-full bg-gray-50 border-2 border-gray-900 pl-9 pr-4 py-1.5 rounded text-sm text-gray-900 font-bold focus:outline-none focus:border-app-purple"
                autoFocus
              />
            </div>

            {/* Drawer ingredient list scroll container */}
            <div className="flex-grow overflow-y-auto min-h-0 space-y-2 pr-1">
              {ingredients.filter(ing =>
                ing.name.toLowerCase().includes(searchIngredientQuery.toLowerCase()) ||
                ing.category.toLowerCase().includes(searchIngredientQuery.toLowerCase())
              ).length === 0 ? (
                <div className="text-center py-10 text-gray-500">
                  <p className="font-bold">No se encontró "{searchIngredientQuery}"</p>
                  <p className="text-xs mt-1">Crea primero el ingrediente en la pestaña de Ingredientes para poder usarlo.</p>
                </div>
              ) : (
                ingredients
                  .filter(ing =>
                    ing.name.toLowerCase().includes(searchIngredientQuery.toLowerCase()) ||
                    ing.category.toLowerCase().includes(searchIngredientQuery.toLowerCase())
                  )
                  .map(ing => {
                    const alreadyAdded = calcItems.some(item => item.ingredientId === ing.id);
                    return (
                      <div
                        key={ing.id}
                        id={`drawer-ingredient-row-${ing.id}`}
                        onClick={() => !alreadyAdded && handleAddItemToRecipe(ing.id)}
                        className={`p-3 border-2 rounded flex justify-between items-center transition-all ${
                          alreadyAdded
                            ? 'bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed'
                            : 'bg-white border-gray-300 hover:border-gray-900 hover:bg-gray-50 cursor-pointer active:-translate-y-0.5 shadow-brutal-sm'
                        }`}
                      >
                        <div>
                          <p className="font-black text-sm capitalize">{ing.name}</p>
                          <p className="text-xs font-bold text-gray-500">
                            {formatCurrency(ing.pricePerUnit)} / g ({formatCurrency(ing.pricePerUnit * (ing.purchaseUnit === 'u' ? 1 : 1000))} por {ing.purchaseUnit === 'u' ? 'u' : ing.purchaseUnit})
                          </p>
                        </div>

                        {alreadyAdded ? (
                          <span className="text-[10px] bg-gray-200 text-gray-500 font-black px-2 py-0.5 rounded uppercase">Agregado</span>
                        ) : (
                          <span className="text-[10px] bg-app-peach text-gray-900 border border-gray-900 shadow-brutal-sm font-black px-2 py-0.5 rounded uppercase flex items-center gap-1 group-hover:bg-white">
                            <Plus className="w-3 h-3 stroke-[3]" /> Añadir
                          </span>
                        )}
                      </div>
                    );
                  })
              )}
            </div>

            <div className="pt-3 border-t-2 border-gray-200 mt-4 text-center shrink-0">
              <p className="text-xs text-gray-500 font-medium">¿Falta algún ingrediente en tu lista?</p>
              <button
                id="drawer-go-to-ing-btn"
                onClick={() => {
                  setShowAddIngredientDrawer(false);
                  setActiveTab('ingredients');
                  handleOpenAddDictIngredient();
                }}
                className="mt-1 text-app-purple hover:text-black font-black text-xs underline"
              >
                Crear ingrediente en la Base de Datos
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== MODAL: ADD / EDIT DICTIONARY INGREDIENT ==================== */}
      {showDictModal && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4" onClick={() => setShowDictModal(false)}>
          <form
            onSubmit={handleSaveDictIngredient}
            className="w-full max-w-md bg-white text-gray-900 rounded border-4 border-gray-900 p-6 shadow-brutal animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center pb-4 border-b-2 border-gray-200 mb-5">
              <h3 className="font-sans text-lg font-black uppercase tracking-tight text-gray-900 flex items-center gap-1.5">
                <Apple className="w-5 h-5 text-app-purple fill-current" />
                {isEditingDictIngredient ? 'Editar Ingrediente' : 'Añadir a Base de Datos'}
              </h3>
              <button type="button" onClick={() => setShowDictModal(false)} className="p-1 hover:bg-gray-100 border-2 border-transparent active:border-gray-900 rounded">
                <X className="w-5 h-5 stroke-[2.5]" />
              </button>
            </div>

            <div className="space-y-4 mb-6">
              {/* Ingredient Name */}
              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1">Nombre del Ingrediente</label>
                <input
                  id="dict-name-input"
                  type="text"
                  required
                  placeholder="ej. Mantequilla con Sal, Harina de Fuerza"
                  value={dictName}
                  onChange={(e) => setDictName(e.target.value)}
                  className="w-full bg-gray-50 border-2 border-gray-900 p-2.5 font-bold text-gray-900 rounded focus:outline-none focus:border-app-purple"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 mb-1">Categoría</label>
                <select
                  id="dict-category-input"
                  value={dictCategory}
                  onChange={(e) => setDictCategory(e.target.value)}
                  className="w-full bg-gray-50 border-2 border-gray-900 p-2.5 font-bold text-gray-900 rounded focus:outline-none focus:border-app-purple"
                >
                  <option value="Secos">Secos (Harina, Polvos, etc.)</option>
                  <option value="Lácteos">Lácteos (Mantequilla, Leche, etc.)</option>
                  <option value="Azúcares">Azúcares & Endulzantes</option>
                  <option value="Chocolates">Chocolates & Cacaos</option>
                  <option value="Granos">Granos & Frutos Secos</option>
                  <option value="Frutas">Frutas & Conservas</option>
                  <option value="Otros">Otros Ingredientes</option>
                </select>
              </div>

              {/* Purchase Details */}
              <div className="p-3 bg-gray-50 rounded border-2 border-gray-300">
                <span className="block text-xs font-black uppercase text-gray-800 mb-2">Detalles de Compra del Proveedor</span>
                
                <div className="grid grid-cols-3 gap-2">
                  {/* Purchase Price */}
                  <div className="col-span-1.5">
                    <label className="block text-[10px] font-bold text-gray-600 uppercase mb-0.5">Precio ($)</label>
                    <div className="relative">
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-500">$</span>
                      <input
                        id="dict-price-input"
                        type="number"
                        required
                        min="1"
                        value={dictPrice || ''}
                        onChange={(e) => setDictPrice(Math.max(1, parseFloat(e.target.value) || 0))}
                        className="w-full bg-white border-2 border-gray-900 py-1.5 pl-5 pr-1 font-bold text-gray-900 text-sm rounded focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Purchase Qty */}
                  <div>
                    <label className="block text-[10px] font-bold text-gray-600 uppercase mb-0.5">Cantidad</label>
                    <input
                      id="dict-qty-input"
                      type="number"
                      required
                      min="1"
                      value={dictQty || ''}
                      onChange={(e) => setDictQty(Math.max(1, parseFloat(e.target.value) || 0))}
                      className="w-full bg-white border-2 border-gray-900 py-1.5 px-2 font-bold text-gray-900 text-sm rounded focus:outline-none text-right"
                    />
                  </div>

                  {/* Purchase Unit */}
                  <div>
                    <label className="block text-[10px] font-bold text-gray-600 uppercase mb-0.5">Unidad</label>
                    <select
                      id="dict-unit-input"
                      value={dictUnit}
                      onChange={(e) => setDictUnit(e.target.value as any)}
                      className="w-full bg-white border-2 border-gray-900 py-1.5 px-1 font-bold text-gray-900 text-xs rounded focus:outline-none"
                    >
                      <option value="g">gramos (g)</option>
                      <option value="kg">kilogramos (kg)</option>
                      <option value="ml">mililitros (ml)</option>
                      <option value="L">litros (L)</option>
                      <option value="u">unidades (u)</option>
                    </select>
                  </div>
                </div>

                <p className="text-[10px] text-gray-500 mt-2 font-medium">
                  {/* Informational unit breakdown preview */}
                  {dictQty && dictPrice ? (
                    <span>
                      Costo estimado: <strong>
                        {formatCurrency(
                          dictPrice / (
                            dictUnit === 'kg' || dictUnit === 'L' ? dictQty * 1000 : dictQty
                          )
                        )}
                      </strong> por {dictUnit === 'u' ? 'unidad' : 'gramo / mililitro'}.
                    </span>
                  ) : null}
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                id="cancel-dict-btn"
                type="button"
                onClick={() => setShowDictModal(false)}
                className="flex-1 py-2.5 border-2 border-gray-900 font-bold rounded text-sm hover:bg-gray-100 transition-colors"
              >
                Cancelar
              </button>
              
              <button
                id="submit-dict-btn"
                type="submit"
                className="flex-1 py-2.5 bg-app-peach text-gray-900 border-2 border-gray-900 font-bold rounded text-sm shadow-brutal-sm hover:bg-white active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all flex items-center justify-center gap-1"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Guardar</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
